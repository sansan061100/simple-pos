<link rel="stylesheet" href="{{ asset('') }}plugins/select2/css/select2.min.css">
<link rel="stylesheet" href="{{ asset('') }}plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">