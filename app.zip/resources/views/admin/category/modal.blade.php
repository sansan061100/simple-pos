<form id="form-store">
    <x-modal>
        <input type="hidden" name="id">
        <div class="form-group">
            <label>Name</label>
            <input type="text" name="name" class="form-control">
        </div>
    </x-modal>
</form>
