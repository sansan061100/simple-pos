<form id="form-stock">
    <?php if (isset($component)) { $__componentOriginale6a555649da86b3de44465cdfe004aa4 = $component; } ?>
<?php $component = App\View\Components\Modal::resolve(['modalId' => 'modal-stock','modalTitleClass' => 'modal-title-stock'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="form-group" id="product">
            <label>Product</label>
            <select name="product" class="form-control w-100">
            </select>
        </div>
        <div class="form-group">
            <label>Qty</label>
            <input type="text" name="qty" class="form-control numericInput" autocomplete="off">
        </div>
        <div class="form-group">
            <label>Purchase Price</label>
            <input type="text" name="purchase_price" class="form-control currencyInput" autocomplete="off">
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6a555649da86b3de44465cdfe004aa4)): ?>
<?php $component = $__componentOriginale6a555649da86b3de44465cdfe004aa4; ?>
<?php unset($__componentOriginale6a555649da86b3de44465cdfe004aa4); ?>
<?php endif; ?>
</form><?php /**PATH D:\SANSAN\Latihan\Laravel\simple-pos\resources\views/admin/product/modal-stock.blade.php ENDPATH**/ ?>