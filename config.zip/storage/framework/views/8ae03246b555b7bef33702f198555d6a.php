<!-- jQuery -->
<script src="<?php echo e(asset('')); ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('')); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('')); ?>dist/js/adminlte.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

<script src="<?php echo e(asset('')); ?>dist/js/app.js?v=<?php echo e(microtime()); ?>"></script><?php /**PATH D:\SANSAN\Latihan\Laravel\simple-pos\resources\views/admin/layouts/_scripts.blade.php ENDPATH**/ ?>