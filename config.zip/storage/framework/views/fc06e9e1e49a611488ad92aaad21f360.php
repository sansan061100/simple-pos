<?php $__env->startSection('content'); ?>
    <?php
        $invoiceCode = 'INV-' . date('YmdHis');
    ?>
    <form @submit.prevent="$store.pos.checkout()" method="POST" x-data>

        <section class="section-content padding-y-sm bg-default " x-data>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card" x-init="$store.pos.init()">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="">Cashier</label>
                                                    <input type="text" disabled value="<?php echo e(auth()->user()->name); ?>"
                                                        class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group" x-init="() => {
                                                    select2 = $($refs.select).select2({
                                                        theme: 'bootstrap4',
                                                    });
                                                    select2.on('select2:select', (event) => {
                                                        $store.pos.customer = event.target.value;
                                                    });
                                                }">
                                                    <label for="">Customer</label>
                                                    <select class="form-control" x-model="$store.pos.customer"
                                                        x-ref="select">
                                                        <option value="">Customer</option>
                                                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="fa fa-search"></i></span>
                                            </div>
                                            <input type="search" class="form-control" placeholder="Search..."
                                                x-model="$store.pos.search" @input="$store.pos.fetchProduct()">
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <ul class=" nav bg radius nav-pills nav-fill mb-3 bg" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link active show" data-toggle="pill"
                                                    @click="$store.pos.category = ''; $store.pos.fetchProduct()">
                                                    <i class="fa fa-tags pr-2"></i> All</a>
                                            </li>
                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="nav-item">
                                                    <a class="nav-link" data-toggle="pill"
                                                        @click="$store.pos.category = <?php echo e($item->id); ?>; $store.pos.fetchProduct()">
                                                        <i class="fa fa-tags pr-2"></i> <?php echo e($item->name); ?></a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <?php echo $__env->make('admin.order.components.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <?php echo $__env->make('admin.order.components.cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="box">
                            
                            <dl class="dlist-align">
                                <dt>Discount:</dt>
                                <dd class="text-right">
                                    <div class="input-group">
                                        <input type="number" class="form-control" x-model="$store.pos.discount"
                                            max="100" min="0" @keyup="$store.pos.calculate()">
                                        <div class="input-group-append">
                                            <span class="input-group-text">%</span>
                                        </div>
                                    </div>
                                </dd>
                            </dl>
                            <dl class="dlist-align">
                                <dt>Paid:</dt>
                                <dd class="text-right">
                                    <div class="input-group" x-init="paid = $($refs.paid).inputmask({
                                        alias: 'currency',
                                        prefix: 'Rp ',
                                        digits: 0,
                                        groupSeparator: '.',
                                        rightAlign: false,
                                    });
                                    paid.on('keyup', (event) => {
                                        $store.pos.paid = event.target.value;
                                        $store.pos.calculate();
                                    });">
                                        <input type="text" class="form-control" x-ref="paid">
                                    </div>
                                </dd>
                            </dl>
                            <dl class="dlist-align">
                                <dt>Sub Total:</dt>
                                <h5 class="text-right" x-text="rupiah($store.pos.subTotal)"></h5>
                            </dl>
                            <dl class="dlist-align">
                                <dt>Total: </dt>
                                <dd class="text-right h4" x-text="rupiah($store.pos.total)"></dd>
                            </dl>
                            <dl class="dlist-align">
                                <dt>Charge: </dt>
                                <dd class="text-right h4" x-text="rupiah($store.pos.charge)"></dd>
                            </dl>

                            <hr>

                            <div class="row">
                                <div class="col-md-6">
                                    <a href="<?php echo e(route('admin.order.index')); ?>" class="btn btn-danger btn-lg btn-block"><i
                                            class="fa fa-times-circle "></i> Cancel
                                    </a>
                                </div>
                                <div class="col-md-6">
                                    <button type="submit" class="btn  btn-primary btn-lg btn-block"><i
                                            class="fa fa-shopping-bag"></i>
                                        Charge </button>
                                </div>
                            </div>
                        </div> <!-- box.// -->
                    </div>
                </div>
            </div><!-- container //  -->
        </section>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <?php echo $__env->make('admin.plugins.select2-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/pos.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('admin.plugins.select2-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.plugins.jquery-mask-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="//unpkg.com/alpinejs" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/axios@1.1.2/dist/axios.min.js"></script>
    <script>
        $('.select2').select2({
            theme: 'bootstrap4'
        });
    </script>
    <script src="<?php echo e(asset('dist/js/pos.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.pos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SANSAN\Latihan\Laravel\simple-pos\resources\views/admin/order/create.blade.php ENDPATH**/ ?>