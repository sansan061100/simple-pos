<script src="<?php echo e(asset('')); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('')); ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo e(asset('')); ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo e(asset('')); ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<?php /**PATH D:\SANSAN\Latihan\Laravel\simple-pos\resources\views/admin/plugins/datatable-js.blade.php ENDPATH**/ ?>