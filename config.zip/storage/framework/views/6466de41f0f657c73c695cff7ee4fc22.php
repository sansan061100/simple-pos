<link rel="stylesheet" href="<?php echo e(asset('')); ?>plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('')); ?>plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo e(asset('')); ?>plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
<?php /**PATH D:\SANSAN\Latihan\Laravel\simple-pos\resources\views/admin/plugins/datatable-css.blade.php ENDPATH**/ ?>