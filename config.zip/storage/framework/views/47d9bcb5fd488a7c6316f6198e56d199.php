<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.min.css">
<style>
    .dropify-wrapper .dropify-message p {
        font-size: 20px;
    }
</style><?php /**PATH D:\SANSAN\Latihan\Laravel\simple-pos\resources\views/admin/plugins/dropify-css.blade.php ENDPATH**/ ?>