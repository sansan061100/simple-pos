<?php

return [
    'stock' => [
        'in' => 1,
        'out' => 0
    ]
];
